#./silc.SF > ./silc.SF.log
#./silc.NA > ./silc.NA.log
./silc.col > silc.col.log
./silc.fla > silc.fla.log
