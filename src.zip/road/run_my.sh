rm  ./bin/hiernn_gtree
make hiernn_gtree
scp ./bin/hiernn_gtree dmteam@166.111.17.125:/home/dmteam/dataSets/exp_data/road_e_n_data/

