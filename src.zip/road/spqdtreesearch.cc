/* ----------------------------------------------------------------------------
    Author: Ken C. K. Lee
    Email:  cklee@cse.psu.edu
    Web:    http://www.cse.psu.edu/~cklee
    Date:   Nov, 2008
---------------------------------------------------------------------------- */

#include "spqdtreesearch.h"

SPQuadtreeNode* SPQuadtreeSearch::ptSearch(SPQuadtree& a_tree, Point& a_pt)
{
    return 0;
}